import React from 'react';
import { useParams } from 'react-router-dom';
import useServiceDetails from '../../hooks/useServiceDetails';
import PageTitle from '../../Shared/PageTitle/PageTitle';
import './Checkout.css';
import { ToastContainer, toast } from 'react-toastify';
import axios from 'axios';

const Checkout = () => {
    const { serviceId } = useParams();
    const [service] = useServiceDetails(serviceId);

    const handlePlaceOrder = event => {
        event.preventDefault();
        
        const order = {
            service: service.name,
            serviceId: serviceId,
            address: event.target.address.value,
            phone: event.target.phone.value
        };

        axios.post('https://car-service-sserver.onrender.com/order', order)
        .then(response => {
            const { data } = response;
            if (data.insertedId) {
                toast('Order placed');
                event.target.reset();
            }
        })
        .catch(error => {
            toast.error('Failed to place order');
        });
    };

    return (
        <div>
            <PageTitle title="Checkout"></PageTitle>
            <h1 className='checkout-h1'>Checkout</h1>
            <div className='w-50 mx-auto'>
                <h2>Ordering : {service.name}</h2>
                <form onSubmit={handlePlaceOrder}>
                    <input className='w-100 m-2' type="text" value="Name" name="name" placeholder="name" required readOnly />
                    <br/>
                    <input className='w-100 m-2' type="text" value="Email" name="email" placeholder="email" required readOnly />
                    <br/>
                    <input className='w-100 m-2' type="text" value={service.name} name="service" placeholder="service" required readOnly />
                    <br/>
                    <input className='w-100 m-2' type="text" name="address" placeholder="address" autoComplete='off' required />
                    <br/>
                    <input className='w-100 m-2' type="text" name="phone" placeholder="phone" required />
                    <br/>
                    <input className='p-2 m-3 btn btn-primary' type="submit" value="Place Order" />
                </form>
                <ToastContainer />
            </div>
        </div>
    );
};

export default Checkout;
