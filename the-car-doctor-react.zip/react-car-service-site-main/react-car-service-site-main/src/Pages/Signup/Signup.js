import React, { useState } from "react";
import { Button, Form } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import Loading from "../Shared/Loading/Loading";
import PageTitle from "../Shared/PageTitle/PageTitle";
import './Signup.css';

const Signup = () => {
  const [agree, setAgree] = useState(false);
  const [loading, setLoading] = useState(false); // Added loading state
  const [error, setError] = useState(null); // Added error state

  const navigate = useNavigate();

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true); // Start loading

    const email = event.target.email.value;
    const password = event.target.password.value;
    const name = event.target.name.value;

    // Dummy user creation logic (replace with your own)
    try {
      // Simulate user creation
      console.log("User created:", { name, email, password });

      // Redirect after successful signup
      navigate("/login");
    } catch (error) {
      setError("Signup failed. Please try again."); // Set error message
    } finally {
      setLoading(false); // Stop loading
    }
  };

  const navigateLogin = () => {
    navigate("/login");
  };

  if (loading) {
    return <Loading />;
  }

  return (
    <div>
      <PageTitle title="Signup" />
      <h2 className="signup-h1">Sign up</h2>
      <div className="container py-5 w-50">
        <Form noValidate onSubmit={handleSubmit}>
          <Form.Group className="mb-3">
            <Form.Label>Your Name</Form.Label>
            <Form.Control
              type="text"
              name="name"
              placeholder="Your name"
              required
            />
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Email address</Form.Label>
            <Form.Control
              type="email"
              name="email"
              placeholder="Enter email"
              required
            />
            <Form.Text className="text-muted">
              We'll never share your email with anyone else.
            </Form.Text>
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Control
              type="password"
              name="password"
              placeholder="Password"
              required
            />
          </Form.Group>
          <Form.Group className="mb-3">
            <Form.Check
              onClick={() => setAgree(!agree)}
              type="checkbox"
              label="Accept terms and condition"
            />
          </Form.Group>
          <Button className="btn btn-primary" type="submit" disabled={!agree}>
            Signup
          </Button>
        </Form>

        {error && <p className="text-danger text-center mt-2">{error}</p>} {/* Error message */}

        <p className="text-center">
          Already have an account?{" "}
          <span
            style={{ cursor: "pointer" }}
            className="text-decoration-underline text-danger"
            onClick={navigateLogin}
          >
            Please Login
          </span>
        </p>
      </div>
    </div>
  );
};

export default Signup;
