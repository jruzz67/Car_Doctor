import React from "react";
import { Navigate, useLocation } from "react-router-dom";
import Loading from "../../Shared/Loading/Loading";
import { ToastContainer, toast } from "react-toastify";

const RequireAuth = ({ children }) => {
  const user = null;  
  const loading = false;  
  const location = useLocation();
   if (loading) {
    return <Loading />;
  }
  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }
  return children;
};

export default RequireAuth;
