import { Button } from "react-bootstrap";
import React, { useRef, useState } from "react";
import { Form } from "react-bootstrap";
import { useLocation, useNavigate } from "react-router-dom";
import SocialLogin from "./SocialLogin/SocialLogin";
import Loading from "../Shared/Loading/Loading";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import PageTitle from "../Shared/PageTitle/PageTitle";

const Login = () => {
  const emailRef = useRef("");
  const passRef = useRef("");
  const navigate = useNavigate();
  const location = useLocation();

  let from = location.state?.from?.pathname || "/";

  const [user, setUser] = useState(null); // Placeholder for user state
  const [loading, setLoading] = useState(false); // Placeholder for loading state
  const [error, setError] = useState(null); // Placeholder for error state
  const [validated, setValidated] = useState(false);

  let errorElement;

  if (error) {
    errorElement = <p className="text-danger mt-2">Error: {error.message}</p>;
  }

  if (user) {
    // Assuming the user state is updated upon successful login
    navigate(from, { replace: true });
  }

  const handleSubmit = async (event) => {
    event.preventDefault();
    const email = emailRef.current.value;
    const pass = passRef.current.value;

    // Implement custom sign-in logic here
    setLoading(true);
    try {
      // Simulate sign-in process
      // Example: await customSignInFunction(email, pass);
      setUser({ email }); // Update with actual user data
      setLoading(false);
    } catch (e) {
      setError(e);
      setLoading(false);
    }

    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    }

    setValidated(true);
  };

  if (loading) {
    return <Loading />;
  }

  const navigateSignup = () => {
    navigate(`/signup`);
  };

  const resetPassword = async () => {
    const email = emailRef.current.value;
    if (email) {
      // Implement custom password reset logic here
      toast('Password reset email sent');
    } else {
      toast('Please enter your email address');
    }
  };

  return (
    <div className="container py-3 w-50">
      <PageTitle title="Login"></PageTitle>
      <h2 className="mt-5 text-primary fw-bold text-center">Log In</h2>
      <Form noValidate validated={validated} onSubmit={handleSubmit}>
        <Form.Group className="mb-3" controlId="formBasicEmail">
          <Form.Label>Email address</Form.Label>
          <Form.Control
            ref={emailRef}
            type="email"
            placeholder="Enter email"
            required
          />
          <Form.Text className="text-muted">
            We'll never share your email with anyone else.
          </Form.Text>
        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicPassword">
          <Form.Label>Password</Form.Label>
          <Form.Control
            ref={passRef}
            type="password"
            placeholder="Password"
            required
          />
        </Form.Group>
        <p
          onClick={resetPassword}
          style={{ cursor: "pointer" }}
          className="text-decoration-underline text-danger"
        >
          Forgot Password?
        </p>

        <Button className="btn btn-primary" type="submit">
          Login
        </Button>
      </Form>
      {errorElement}

      <p className="text-center">
        New to Car service?{" "}
        <span
          style={{ cursor: "pointer" }}
          className="text-decoration-underline text-danger"
          onClick={navigateSignup}
        >
          Please Signup
        </span>
      </p>
      <SocialLogin />
      <ToastContainer />
    </div>
  );
};

export default Login;
