import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import './Order.css';

const Order = () => {
  const [orders, setOrders] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const getOrders = async () => {
      const email = ""; // Replace with user's email from your custom auth logic
      const url = `https://car-service-sserver.onrender.com/order?email=${email}`;
      try {
        const { data } = await axios.get(url, {
          headers: {
            authorization: `Bearer ${localStorage.getItem("accessToken")}`,
          },
        });
        setOrders(data);
      } catch (error) {
        if (error.response.status === 403 || error.response.status === 401) {
          // Implement your custom sign-out logic here
          // Example: customSignOutFunction();
          navigate("/login");
        }
      }
    };
    getOrders();
  }, [navigate]);

  return (
    <div>
      <h2 className='mb-4 order-h1'>Your Orders</h2>
      <div className="w-50 mx-auto mt-3 p-3">
        <h2>Orders : {orders.length}</h2>
        {orders.map((order) => (
          <div className="p-3" key={order._id}>
            <p>Email : {order.email}</p>
            <p>Item name : {order.service}</p>
            <p>Address : {order.address}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Order;
